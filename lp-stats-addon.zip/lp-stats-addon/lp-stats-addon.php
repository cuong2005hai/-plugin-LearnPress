<?php
/*
Plugin Name: LearnPress Stats Dashboard
Description: Hien thi thong ke LearnPress tren Dashboard va Shortcode
Version: 1.0
Author: Sinh vien
*/

if (!defined('ABSPATH')) exit;

// Lay tong khoa hoc
function lp_get_total_courses() {
    global $wpdb;
    return $wpdb->get_var("SELECT COUNT(ID) FROM {$wpdb->posts} WHERE post_type = 'lp_course' AND post_status = 'publish'");
}

// Lay tong hoc vien
function lp_get_total_students() {
    global $wpdb;
    return $wpdb->get_var("SELECT COUNT(DISTINCT user_id) FROM {$wpdb->prefix}learnpress_user_items WHERE item_type = 'lp_course'");
}

// Lay so khoa hoc hoan thanh
function lp_get_completed_courses() {
    global $wpdb;
    return $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}learnpress_user_items WHERE status = 'completed' AND item_type = 'lp_course'");
}

// Dashboard Widget
function lp_stats_dashboard_widget() {
    wp_add_dashboard_widget(
        'lp_stats_widget',
        'LearnPress Stats',
        'lp_stats_widget_display'
    );
}
add_action('wp_dashboard_setup', 'lp_stats_dashboard_widget');

function lp_stats_widget_display() {
    echo '<p><strong>Tong khoa hoc:</strong> ' . lp_get_total_courses() . '</p>';
    echo '<p><strong>Tong hoc vien:</strong> ' . lp_get_total_students() . '</p>';
    echo '<p><strong>Khoa hoc hoan thanh:</strong> ' . lp_get_completed_courses() . '</p>';
}

// Shortcode
function lp_total_stats_shortcode() {
    ob_start();
    ?>
    <div style="padding:20px; border:1px solid #ccc; max-width:400px;">
        <h3>Thong ke LearnPress</h3>
        <p><strong>Tong khoa hoc:</strong> <?php echo lp_get_total_courses(); ?></p>
        <p><strong>Tong hoc vien:</strong> <?php echo lp_get_total_students(); ?></p>
        <p><strong>Khoa hoc hoan thanh:</strong> <?php echo lp_get_completed_courses(); ?></p>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('lp_total_stats', 'lp_total_stats_shortcode');
